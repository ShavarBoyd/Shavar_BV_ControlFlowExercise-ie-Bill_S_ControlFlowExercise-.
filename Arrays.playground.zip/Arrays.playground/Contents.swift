import UIKit

var someInts = [Int]()

someInts.append (10)

print("My array has \(10) items.")

print("My favorite things include \(10) items.")

var favoriteThings: [String] = ["Bow", "Laptop","Keyboard","Baseball Glove","Gym Shoes","Backpack","Cap","Wallet","Watch","Iphone 11"]
favoriteThings.sort()
print (favoriteThings)
//prints["Bow","Backpack","Baseball Glove","Cap","Gym Shoes","Iphone 11","keyboard","Laptop","Wallet","Watch"]



var firstItem = favoriteThings[0]




